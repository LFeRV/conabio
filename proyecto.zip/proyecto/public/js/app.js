let auth0 = null;
let token = null;
let user = null;

const fetchAuthConfig = () => fetch("auth_config.json");

const configureClient = async () => {
  const response = await fetchAuthConfig();
  const config = await response.json();
  auth0 = await createAuth0Client({
    domain: config.domain,
    client_id: config.clientId, 
    useRefreshTokens: true, 
    cacheLocation: 'localstorage'
  }); 
};

const updateUI = async () => { 
  const isAuthenticated = await auth0.isAuthenticated(); 
  document.getElementById("btn-logout").disabled =! isAuthenticated;
  document.getElementById("btn-login").disabled = isAuthenticated;
  
  if (isAuthenticated) {
    document.getElementById("gated-content").classList.remove("hidden");
    token = await auth0.getTokenSilently();
    user = await auth0.getUser();
    // var user = await auth0.getUser();
    // var id_a = await auth0.getUser()
    // console.log(user);

    $('#token').val(token);

    $("#gated-content").css("display", "block");
    $("#ipt-user-profile").text(user['nickname']);

    $('#user').val(JSON.stringify(user))
    
    $('#btn-login').css("display", "none");
    $('#btn-logout').css("display", "block");

    console.log('Está autenticado!');

  } else {
    $("#gated-content").css("display", "none");

    console.log('No está autenticado');
  }
};

const login = async () => {
  // console.log(1);
  await auth0.loginWithRedirect({
    redirect_uri: window.location.origin.replace("localhost", "127.0.0.1") + "/JavaBridge/proyectosjm/"//window.location.origin.replace("lroque:8080") + "/JavaBridge/proyectosjm/" // "http://lroque:8080/JavaBridge/proyectosjm/"//window.location.origin.replace("localhost", "127.0.0.1") + "/JavaBridge/proyectosjm" //"http://127.0.0.1:8080/JavaBridge/proyectosjm" //"http://127.0.0.1:8080/JavaBridge/proyectosjm/index.php"//"http://127.0.0.1:8080"//window.location.origin
  });
  const isAuthenticated = await auth0.isAuthenticated();
};

const logout = () => {
  // console.log(0);
  session.clear()
  sessionStorage.clear();
  window.localStorage.clear();
  auth0.logout({
    returnTo: window.location.origin.replace("localhost", "127.0.0.1") + "/JavaBridge/proyectosjm/" //window.location.origin.replace("lroque:8080") + "/JavaBridge/proyectosjm/" //"http://lroque:8080/JavaBridge/proyectosjm/" //window.location.origin.replace("localhost", "127.0.0.1") + "/JavaBridge/proyectosjm" //"http://127.0.0.1:8080/JavaBridge/proyectosjm"//"http://127.0.0.1:8080"//window.location.origin
  });
};


/*
CUANDO SE LEÉ LA PÁGINA index.php se carga este documento, iniciando por la función window.onload para verificar si estas logueado, al ser la primera vez no estarás autentificado
para ello te logueas con el botón correspondiente, si esta bien la función:

await auth0.loginWithRedirect({
    redirect_uri: "http://127.0.0.1:8080/JavaBridge/proyectosjm/index.php" //"http://127.0.0.1:8080/JavaBridge/proyectosjm/index.php"//"http://127.0.0.1:8080"//window.location.origin
  });

te redireccionará al inicio y se volverá a ejecutar la página y este documento para leer de nuevo la función window.onload y ahora si estarás autentificado y se desbloqueará el apartado correspondiente
a la función updateUI

*/

window.onload = async () => {
  await configureClient();
  await updateUI();
  const isAuthenticated = await auth0.isAuthenticated();

  if (isAuthenticated) {
    return;
  }

  const query = window.location.search;

  if (query.includes("code=") && query.includes("state=")) {
    await auth0.handleRedirectCallback();
    await updateUI();
    window.history.replaceState({}, document.title, "/");
  }
};