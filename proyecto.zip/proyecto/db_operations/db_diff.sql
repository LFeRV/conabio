ALTER TABLE analistas ADD COLUMN id_auth0 varchar(100);
ALTER TABLE coberturas ADD COLUMN abierto boolean DEFAULT 1;