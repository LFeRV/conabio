﻿<?php  
require_once("java/Java.inc"); 
ini_set("display_errors", "on");

function conectar()
{
	//"host=200.12.166.29 port=5432 dbname=Metadatos user=postgres password=sig123456"
	//"host=localhost port=5432 dbname=Metadatos_W user=postgres password=postgres"
	//host=200.12.166.29 port=5432 dbname=Metadatos_W user=postgres password=sig123456
	$db = pg_pconnect("host=localhost port=5432 dbname=Metadatos_W user=postgres password=postgres") or die( "Error al conectar a Metadatos: ".pg_last_error() );
   	if (!$db) { exit('Error en la conexión a la base de datos METADATOS'); } 
   	else{ return $db;} 
}

function catalogos()
{
	//"host=200.12.166.29 port=5432 dbname=Catalogos user=postgres password=sig123456"
	//"host=localhost port=5432 dbname=Catalogos_W user=postgres password=postgres"
	//host=200.12.166.29 port=5432 dbname=Catalogos_W user=postgres password=sig123456
	$cat = pg_pconnect("host=localhost port=5432 dbname=Catalogos_W user=postgres password=postgres") or die( "Error al conectar a Catalogos: ".pg_last_error() );
   	if (!$cat) { exit('Error en la conexión a la base de datos CATALOGOS'); } 
   	else{ return $cat;} 
}
?>