<?php

	
	function get(){

	}
	
	function post_string($url, $path, ){



	}


?>