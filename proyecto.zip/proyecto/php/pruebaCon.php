<?php
ini_set("display_errors", "on");
header('Content-Type: text/html; charset=utf-8'); 
require_once("java/Java.inc"); 
ini_set("display_errors", "on");

//"host=200.12.166.29 port=5432 dbname=Metadatos user=postgres password=sig123456"
//"host=localhost port=5432 dbname=Metadatos user=postgres password=postgres"
//host=200.12.166.29 port=5432 dbname=acervo2018 user=postgres password=sig123456
//host=200.12.166.29 port=5432 dbname=Metadatos_W user=postgres password=sig123456
$db = pg_pconnect("host=200.12.166.29 port=5432 dbname=acervo2018 user=postgres password=sig123456") or die( "Error al conectar al acervo: ".pg_last_error() );
if (!$db) {
   	exit('Error en la conexión a la base de datos acervo');
}else{
	$sqlSelect = pg_query($db, "SELECT * FROM tax_nom59_met"); or die (pg_last_error($db)); 
	$jsondata["numRows"] = pg_num_rows($sqlSelect);
	header('Content-type: application/json; charset=utf-8');
	echo json_encode($jsondata);
} 
?>