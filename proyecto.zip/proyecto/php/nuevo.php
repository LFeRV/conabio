<?php 
// session_start();
// if ( ! ($_SESSION['autenticado'] == 'SI' && isset($_SESSION['uid'])) )
// {
// 		$mensajesAll = "Su sesion ha finalizado.";
// 		if ( $mensajesAll != "" ) 
// 		{
// 			echo "<form name=\"error\"  id=\"frm_error\" method=\"post\" action=\"index.php\">";
// 				echo "<input type=\"hidden\" name=\"actualiza_error\" value=\"1\" />";
// 				echo "<input type=\"hidden\" name=\"msg_error\" value=\"$mensajesAll\">";
// 			echo "</form>";
// 			echo "<script type=\"text/javascript\"> ";
// 				echo "document.error.submit();";
// 			echo "</script>";
// 		}
// }
// else
// {

	ini_set("display_errors", "on");
	header('Content-Type: text/html; charset=utf-8'); 
	// $cv_principal = isset($_POST['cv_principal']) ? $_POST['cv_principal'] : null ;
	// $record_id= isset($_POST['id_general']) ? $_POST['id_general'] : null ;
	// $nuevo_proyecto = isset($_POST['name']) ? $_POST['name'] : null ;

	require('conexion.php');
	//require('php/funciones.php');
	// require('funciones.php');
	$db = conectar();
	echo $db;
	if ($db)
	{
		$cv_principal = isset($_POST['cv_principal']) ? $_POST['cv_principal'] : null ;
		// $record_id= isset($_POST['id_general']) ? $_POST['id_general'] : null ;
		$nuevo_proyecto= isset($_POST['name']) ? $_POST['name'] : null ;

		// echo 'console.log("'.$nuevo_proyecto.'" "'.$cv_principal.'")';

		/*CODIGO AGREGADO PARA RECUPERAR EL ID DEL ANALISTA DADO QUE AUTH0 REEMPLAZO cv_principal*/
		//SELECT "idAnalista" FROM analistas WHERE id_auth0 = 'auth0|5ff8cef30e1a380076f0b2ad' LIMIT 1
		$solicitud = "SELECT \"idAnalista\" FROM analistas WHERE id_auth0 = '$cv_principal' LIMIT 1"; 
		// echo 'console.log("'.$solicitud.'")';
		
		$idAn_sql = pg_query($db, $solicitud);
		if (!$idAn_sql) { exit("Error al buscar el id del usuario"); }
		while ($fila = pg_fetch_array($idAn_sql, null, PGSQL_ASSOC))	
			{	
				$idAn = $fila ["idAnalista"];
			}


		/*TERMINA ESPACIO AGREGADO*/
		// echo 'console.log('.$idAn.')';
		
		$sql_nuevo = pg_query($db, "SELECT record_id FROM coberturas ORDER BY record_id DESC LIMIT 1");
		if (!$sql_nuevo) { exit("Error al Buscar el valor maximo de coberturas (record_id)"); }
		
		$id_nuevo = 0;
		
		if (pg_num_rows ($sql_nuevo) <> "")
		{
			while ($fila = pg_fetch_array($sql_nuevo, null, PGSQL_ASSOC))	
			{	
				$id_nuevo = $fila ["record_id"];
				$id_nuevo = $id_nuevo + 1;
			}
		}
		else {$id_nuevo = $id_nuevo + 1;}
		
		$sql_nuevoid = pg_query($db, 'SELECT "id_nuevo" FROM coberturas ORDER BY "id_nuevo" DESC LIMIT 1');
		if (!$sql_nuevoid) { exit("Error al Buscar el valor maximo de coberturas (IDNuevo)"); }

		$id_key = 0;
		
		if (pg_num_rows ($sql_nuevoid) <> "")
		{
			while ($fila = pg_fetch_array($sql_nuevoid, null, PGSQL_ASSOC))	
			{	
				$id_key = $fila ["id_nuevo"];
				$id_key = $id_key + 1;
			}
		}
		
		else {$id_key = $id_key + 1;}
		
		// $solicitud = "IDNuevo: $id_key record_id: $id_nuevo id analista: $idAn nombre del Proyecto: $nuevo_proyecto";
		// echo 'console.log("'.$solicitud.'")';

		
		
		$sql_buscaNombre = pg_query($db, "SELECT nombre FROM coberturas  WHERE nombre = '".$nuevo_proyecto."'");
		if (!$sql_buscaNombre) { exit("Error al Buscar nombres iguales"); }
		
		//echo (pg_num_rows($sql_buscaNombre));
		
		if (pg_num_rows ($sql_buscaNombre) == 0)
		{
			
			$sqlupd  = "BEGIN;INSERT INTO coberturas (id_nuevo ,record_id , nombre , id_analista) VALUES ( ";
			$sqlupd .= " ".$id_key.	" , ";
			$sqlupd .= " '".$id_nuevo."',  "; 
			$sqlupd .= " '".$nuevo_proyecto."',  "; 
			$sqlupd .= " '".$idAn."'";
			/*$sqlupd .= " '".$cv_principal.	"'  ";*/ 	/*LINEA MODIFICADA*/
			$sqlupd .= " ); COMMIT;";
			// echo 'console.log("'.$sqlupd.'")';
			$sql =  pg_query($db, $sqlupd);
			if (!$sql) { exit("Error al insertar la informacion  de atributos en el div 10"); }
			
			//echo "se ha insertado";
			
			$mensajesAll = "El Metadato a sido creado.";
			if ( $mensajesAll != "" ) 
			{
				echo "<form id=\"frm_guardar\" name=\"frm_guardar\" method=\"post\" action=\"Menu.php?id=$id_nuevo\">";
					echo "<input type=\"hidden\" name=\"actualiza\" value=\"1\" />";
					echo "<input type=\"hidden\" name=\"msgs_actualiza\" value=\"$mensajesAll\" />";
				echo "</form>";
				echo "<script type=\"text/javascript\">";
					echo "document.frm_guardar.submit();";
				echo "</script>";
			} 
		}
		
		else
		{
			$mensajesAll = "Existe al menos un metadato con el mismo nombre";
			if ( $mensajesAll != "" ) 
			{
				echo "<form id=\"frm_guardar\" name=\"frm_guardar\" method=\"post\" action=\"Menu.php\">";
					echo "<input type=\"hidden\" name=\"error\" value=\"1\" />";
					echo "<input type=\"hidden\" name=\"msgs_error\" value=\"$mensajesAll\" />";
				echo "</form>";
				echo "<script type=\"text/javascript\">";
					echo "document.frm_guardar.submit();";
				echo "</script>";
			} 
		}
	}// fin if DB	
// } // fin else
?>